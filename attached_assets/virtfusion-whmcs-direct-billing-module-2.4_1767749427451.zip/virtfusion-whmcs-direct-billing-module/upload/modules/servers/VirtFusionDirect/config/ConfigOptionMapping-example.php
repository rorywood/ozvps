<?php

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

return [
    'ipv4' => 'IPv4',
    'packageId' => 'Package',
    'hypervisorId' => 'Location',
    'storage' => 'Storage',
    'memory' => 'Memory',
    'traffic' => 'Bandwidth',
    'networkSpeedInbound' => 'Inbound Network Speed',
    'networkSpeedOutbound' => 'Outbound Network Speed',
    'cpuCores' => 'CPU Cores',
    'networkProfile' => 'Network Type',
    'storageProfile' => 'Storage Type',
];